"""
Parses csv data files to generate the data for PSL in the format
 * inmovie.txt: (actor, movie) <tab> movie_id
 * actressname.txt: a_id <tab> actor
 * sim.txt: a_id1 <tab> a_id2
 * candsame.txt: (actor, movie) <tab> (actor, movie)
Notes:
 * `a_id1` is a unique id that is incremented with *every* name we see.
 * `movie_id` is a unique movie identifier, unique to *each* movie
"""

import sys
import time
import logging
import pandas as pd
import numpy as np
import csv
from multiprocessing import cpu_count, Pool
import Levenshtein
import scipy.special
import itertools


# global data structure
data = pd.DataFrame()


def get_inmovie(df):
    # convert data into inmovie format
    ref_movie = []
    refs = []
    for index, row in df.iterrows():
       # movie_cast_id     movie_id
       ref_movie.append("%s\t%s" %(index, row["movie_cast_movie_id"]))

    returned = pd.DataFrame(ref_movie, columns=['refmovie'])

    return returned

def get_inref(df):
    # convert data into inref format
    ref_movie = []
    refs = []
    for index, row in df.iterrows():
       alias_or_person_id = row['movie_cast_alias_id'] if pd.notnull(row["movie_cast_alias_id"]) else row['movie_cast_person_id']

       # alias_or_name_id     movie_cast_alias_id
       ref_movie.append("%s\t%s" %(alias_or_person_id, index))

    return pd.DataFrame(ref_movie, columns=['inref'])

def get_sim(df, threshold=0.5):
    """
    DataFrame columns that this func expects:
    name1: the first alias name or person name
    name2: the second alias name or person name
    id1: the first alias id or person id (depending on null value of alias id)
    id2: the second alias id or person id (depending on null value of alias id)
    """
    # calculate the levenshtein jaro similarity between two strings
    scores = df.apply(lambda row: Levenshtein.jaro(row["name1"], row["name2"]), axis=1)

    # combine those scores with the original df (that contain the names)
    lev_jaro = df.assign(score=scores)

    # return only the rows that are above threshold
    kept = lev_jaro[lev_jaro.score.apply(lambda x: x > threshold)]

    # convert the data into the string format expected
    returned = pd.DataFrame(kept.apply(lambda row: "%s\t%s" % (row["id1"], row["id2"]),
        axis=1), columns=["sim"])

    return returned

def get_candsame(movie_pairs):
    """
    Returns movie_cast_id \t movie_cast_id
    """
    print(data.shape)

    all_pairs = []

    for pair in movie_pairs:
        df_one = data[data['movie_cast_movie_id']==pair[0]]
        df_two = data[data['movie_cast_movie_id']==pair[1]]
        pairs_ids = list(df_one.index) + list(df_two.index)
        
        for pair_ids in itertools.combinations(pairs_ids,2):
            all_pairs.append("%s\t%s" % (pair_ids[0], pair_ids[1]))

    return pd.DataFrame(all_pairs, columns=["candsame"]) 

def parse_data(movie_filename, alias_filename, cores_to_use=None):
    """
    Parses file under filename into the correct chunks for PSL
    Expected file format:
    "movie_cast.id","movie_cast.alias_id","movie_cast.person_id","movie_cast.movie_id","movies.title","persons.name"
    """
    global data
    # Read in movie and person data
    movie_person = pd.read_csv(movie_filename,
            quotechar="'", delimiter=",", header=None,
            names=["movie_cast_id","movie_cast_alias_id","movie_cast_person_id",
                "movie_cast_movie_id","movies_title","persons_name"],
            na_values="\\N", dtype=str)

    # Read in alias to name data
    alias_name = pd.read_csv(alias_filename,
            header=None, delimiter=",",  quotechar='"',
            names=['id','name', 'alias'], na_values="\\N", dtype=str)

    # Set the id column as the index.
    alias_name.set_index("id", inplace=True)

    # Join the data on the id of alias if present
    data = movie_person.join(alias_name, on='movie_cast_alias_id', how='left', rsuffix='alias_name')

    # Set the id column of movie_cast as index
    data.set_index("movie_cast_id", inplace=True)

    # Narrow down data to movies involing James Bafficio
    keep_titles = ["387001","21613","490399","490400","490401","21615","490402","490403",
            "361871","490404","490405","345738","177550","490406","490407"]
    data = data[data['movie_cast_movie_id'].apply(lambda x: any([x == title for title in
        keep_titles]))]

    print(data.columns)
    print(data.shape)

    # Run for candsame: only do the movies reference is not in

    # generate splits for each pair of titles:
    num_cores = cores_to_use if cores_to_use is not None else cpu_count() - 2
    
    # determine number of pairs to assign to each core (n choose 2 / number_cores)
    num_pairs_per_split = scipy.special.comb(len(keep_titles), 2) / num_cores 
    ids_in_split = []

    # Assign each pair of data to a core
    pairs = list(itertools.combinations(keep_titles,2))
    pairs_split = np.array_split(pairs, num_cores)

    pool = Pool()
    data_cs = pd.concat(pool.map(get_candsame, pairs_split))
    data_cs = data_cs.drop_duplicates()
    pool.close()
    pool.join()


    # split data up for the generation of the rest of the files
    splits = np.array_split(data, num_cores)

    # Run on inreference
    pool = Pool()
    data_inref = pd.concat(pool.map(get_inref, splits))
    data_inref = data_inref.drop_duplicates()
    pool.close()
    pool.join()

    # Run for inmovie
    pool = Pool()
    data_movie = pd.concat(pool.map(get_inmovie, splits))
    data_movie = data_movie.drop_duplicates()
    pool.close()
    pool.join()

    # For similarity we need the full cross product of the names
    side1 = data.assign(id1=data.apply(lambda row: str(row["movie_cast_alias_id"]) if
            pd.notnull(row["movie_cast_alias_id"]) else
            str(row["movie_cast_person_id"]), axis=1))
    side1 = side1.assign(name1=data.apply(lambda row: row["alias"] if
            pd.notnull(row["alias"]) else row["persons_name"], axis=1))
    side1 = side1[["id1", "name1"]]
    side2 = side1.copy()
    side2.columns = ["id2", "name2"]
    cross_prod = side1.assign(foo=1).merge(side2.assign(foo=1)).drop(columns="foo")

    # Run for sim.txt
    pool = Pool()
    splits = np.array_split(cross_prod, num_cores)
    data_sim = pd.concat(pool.map(get_sim, splits))
    data_sim = data_sim.drop_duplicates()
    pool.close()
    pool.join()


    return (data_inref, data_movie, data_sim, data_cs)



if __name__ == "__main__":
    # argparse is prob overkill
    if len(sys.argv) < 3:
        logging.error ("Need to tell me the data filename")
        exit(-1);
    data_filename = sys.argv[1]
    alias_filename = sys.argv[2]
    print("Running %s on data file `%s` and `%s`" % (sys.argv[0], data_filename,
        alias_filename))

    start = time.time()
    inref,inmovie,sim,cs = parse_data(data_filename, alias_filename)
    np.savetxt("inmovie.txt", inmovie.values, fmt="%s")
    np.savetxt("inref.txt", inref.values, fmt="%s")
    np.savetxt("sim.txt", sim.values, fmt="%s")
    np.savetxt("candsame.txt", cs.values, fmt="%s")
    np.savetxt("same_targets.txt", cs.values, fmt="%s")
    end = time.time()

    print("%s done. Ran in %f seconds" % (sys.argv[0], (end-start)))

